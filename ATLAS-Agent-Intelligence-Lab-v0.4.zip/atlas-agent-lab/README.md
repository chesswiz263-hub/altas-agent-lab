# ATLAS — Agent Intelligence Lab

**v0.4.0 · A local-first, model-agnostic agent engineering workbench**  
Python 3.11+ · FastAPI · SQLite/FTS5 · JavaScript dashboard · optional neural embeddings · MIT

> Research, execute, inspect, and evaluate tool-using agents with observable decisions. ATLAS is deliberately an **engineering prototype**: its offline demo is deterministic, its citation checks are not truth oracles, and it is **not a production multi-tenant SaaS**.

## Capabilities

| Layer | Implemented in this repository |
|---|---|
| Agent execution | Bounded ReAct-style agent with allowlisted tools, step budgets, persisted traces, single-agent and sequential four-role team modes |
| Multi-model gateway | Native OpenAI / Anthropic / Gemini adapters and a deterministic **offline** provider; operator-defined model pricing |
| Knowledge | SQLite BM25, lexical n-gram vectors, RRF hybrid fusion, optional SentenceTransformer-based local semantic vectors and semantic RRF |
| v0.3 routing | Explainable *rule-based* auto-routing between one agent and the four-role team |
| **v0.4 durable queue** | Persistent queued jobs, async single-worker execution, cursor-based event polling, cancellation, and restart recovery without repeating in-flight paid calls |
| **v0.4 operator access** | Optional constant-time Bearer-token check for `/api/*` routes except health; token is not stored in browser storage |
| **v0.4 explicit memory** | User-created local notes, FTS5 retrieval, delete controls, **opt-in** incorporation into queued runs only |
| **v0.4 calibration** | Ten hand-labeled isolated citation-surface test cases with per-class precision/recall and confusion matrix |
| Observability | Evidence inspector with explicit citation validation and numeric mismatches, SSE for legacy runs, dashboard traces, local run history |
| Packaging | Docker/Compose on loopback, non-root container, GitHub Actions test matrix, API schema, unit and integration tests |

### What v0.4 does *not* claim

- The queue runs **one active job in one ASGI worker**, using SQLite. It is not a distributed scheduler, and it does not implement hard pre-paid API billing limits or automatic retries. `--workers 1` is required. Queued jobs survive restarts; in-flight ones become `interrupted` and **must be manually re-run**, to avoid accidental charges.
- Cancellation is best effort: an HTTP call may already have reached a provider and may still incur charges. Worker shutdown can also interrupt an active run. Queue events preserve what was observed.
- Optional token access is **single-operator API protection**, not RBAC, TLS, tenant isolation, abuse prevention, rate limiting, CSRF protection for future cookie auth, or complete security hardening. The UI and OpenAPI docs are publicly readable if the server itself is exposed. **Keep the server bound to localhost.**
- Saved memory is **plaintext in SQLite** and is sent to the selected live model provider only when the operator checks *Include saved notes* on a background job. Notes are not automatically inferred, saved, or deleted by the agent. Do not store secrets in notes.
- Citation heuristics and the hand-labeled calibration suite test **surface alignment**, not whether a claim is true. The 10 cases are deliberately simple and are not an external truthfulness dataset.
- Neural search requires a separately installed model and opt-in indexing; it uses exact cosine scans in SQLite, **not ANN / pgvector**. The tested deterministic fake encoder is not a neural-model integration benchmark.

## Quick start

Clone/unzip into the repository root, then:

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -e '.[dev]'
atlas seed
uvicorn atlas.api:app --reload --host 127.0.0.1 --port 8000
```

Open **http://127.0.0.1:8000**. Select **Agent workbench**, leave the offline `demo` provider selected, and run an example prompt. The **background queue** is enabled by default. Click **Cancel active job** while it runs, or review its events under the run history. The legacy streaming path remains available by unchecking background mode. No paid API credentials are needed for the offline demo.

### Optional operator API token

Set `ATLAS_API_TOKEN` to a randomly generated secret of 32+ bytes in a locally secured `.env` or shell environment; never commit `.env`:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
# Set ATLAS_API_TOKEN to the generated value in your local .env
uvicorn atlas.api:app --host 127.0.0.1 --port 8000
```

Paste the token into the dashboard's **API TOKEN** password field. The token stays in memory for this page session (not persisted in localStorage). For API callers, set `Authorization: Bearer <TOKEN>` or `X-Atlas-Token: <TOKEN>`. Without a configured token, the local API is unauthenticated. The `/api/health` endpoint is intentionally unauthenticated for the Docker health probe. Use TLS and an authenticated gateway if you later deploy beyond a trusted local machine.

### Durable job example

```bash
curl -X POST 'http://127.0.0.1:8000/api/jobs' \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"What safeguards are recommended for reliable AI agents?","provider":"demo","mode":"auto","max_steps":3}'
# Response: {"id":"...","status":"queued", ...}

# Replace JOB_ID with the returned id:
curl 'http://127.0.0.1:8000/api/jobs/JOB_ID'
curl 'http://127.0.0.1:8000/api/jobs/JOB_ID/events?after=0'
curl -X POST 'http://127.0.0.1:8000/api/jobs/JOB_ID/cancel'
curl 'http://127.0.0.1:8000/api/runs/JOB_ID'
```

Jobs have statuses `queued`, `running`, `completed`, `budget_exhausted`, `failed`, `cancelled`, or `interrupted`. The run history appears only once execution begins. The job event endpoint supports monotonically increasing `cursor` values so clients can poll without replaying trace entries. Job input and audit events are stored on disk.

### Opt-in remembered context

Visit **Knowledge base → Saved notes**, explicitly save a small note, then in **Agent workbench** select *Include relevant saved notes*. Only for a queued job with `use_memory: true`, ATLAS looks up at most three matching notes and sends their content to the provider as **untrusted data**, not new tool permissions or trusted instructions. You can list and delete notes with `/api/memories`. Legacy SSE routes do not automatically retrieve saved notes.

### Reproducible evidence calibration

In **Evaluation lab**, click *Run calibration*, or call `GET /api/evaluations/calibration`. The endpoint uses a **temporary, isolated database** created from `examples/claim_gold.json` and leaves your documents untouched. Its confusion matrix and per-class precision/recall measure behavior on a tiny set of manually tagged examples, **not cross-domain factuality**. For real-world benchmarking, expand this set with independent human annotations and held-out datasets.

### Optional live models and semantic search

- Set the server-side `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, or `GEMINI_API_KEY` for live model calls; verify provider protocol compatibility and budgets yourself.
- Set `ATLAS_PRICING_JSON={"openai/your-model":[1.25,5.0]}` only with independently verified USD per million token prices for that exact model. Cost stops are **after-observation estimates**, never hard cost ceilings.
- Run `pip install -e '.[semantic]'` and `atlas index-semantic --batch-size 16 --max-chunks 256` for local neural retrieval, then select Neural semantic or Semantic hybrid search. First use may download model weights. You can repeat indexing until all chunks are covered. No model is downloaded during base installation.
- Optional NLI requires `pip install -e '.[nli]'` and `ATLAS_NLI_MODEL` set to a compatible three-class checkpoint. Neither model inference nor NLI accuracy was end-to-end benchmarked in this environment.

## API

| Endpoint | Role |
|---|---|
| `GET /api/health`, `GET /api/status` | Health and local telemetry |
| `POST /api/jobs`, `GET /api/jobs` | Enqueue and list durable jobs |
| `GET /api/jobs/{id}`, `GET /api/jobs/{id}/events?after=N` | Poll a job and its cursor-based events |
| `POST /api/jobs/{id}/cancel` | Cancel pending job or request active cancellation |
| `GET/POST /api/memories`, `DELETE /api/memories/{id}` | Explicit memory notes |
| `GET /api/evaluations/calibration` | Hand-labeled citation heuristic calibration |
| `POST /api/agent/stream`, `/api/team/stream`, `/api/auto/stream` | v0.3 synchronous-response streaming compatibility |
| `GET /api/runs`, `GET /api/runs/{id}` | Persisted agent traces |
| `GET/POST /api/documents`, `DELETE /api/documents/{id}` | Documents |
| `GET /api/search`, `GET /api/embeddings/status`, `POST /api/embeddings/index` | Retrieval and optional index construction |
| `POST /api/route`, `POST /api/verify`, `POST /api/runs/{id}/verify` | Routing and evidence audit |
| `POST /api/evaluations/run`, `POST /api/evaluations/compare` | Retrieval and citation proxy benchmarks |

Interactive API schema is at `/docs` for local development.

## Architecture

```mermaid
flowchart TD
    UI[No-build JavaScript dashboard] --> API[FastAPI / optional bearer-token guard]
    API --> QUEUE[SQLite durable job table]
    QUEUE --> WORKER[One async local worker]
    WORKER --> ROUTER[Explainable policy router]
    ROUTER --> SINGLE[Single agent]
    ROUTER --> TEAM[4-stage sequential team]
    SINGLE --> PROVIDERS[Demo / OpenAI / Anthropic / Gemini]
    TEAM --> PROVIDERS
    SINGLE --> TOOLS[Allowlisted tools]
    TEAM --> TOOLS
    TOOLS --> CORPUS[FTS5 BM25 + lexical vectors + optional neural vectors]
    WORKER --> EVENTS[SQLite run events + status]
    WORKER -. optional .-> MEMORY[Explicit, opt-in notes in SQLite]
    API --> AUDIT[Citation evidence inspector]
    API --> CAL[Isolated calibration fixtures]
```

## Test and package

```bash
pytest -q
# Install dev extras for Ruff lint locally:
ruff check src tests --select E9,F821,F822,F823
node --check static/app.js  # optional, if Node.js is available

docker compose up --build
docker compose exec atlas atlas seed
```

The Docker image deliberately installs only base dependencies; the port is mapped to `127.0.0.1:8000` and the container runs non-root. The durable worker starts with the single web process; **do not configure multiple Uvicorn workers on the same SQLite database**. Stopping the process marks an in-flight run interrupted instead of automatically resuming the same external LLM request.

## Repository map

- `src/atlas/jobs.py` — durable queue, cancellation, worker lifecycle, recoverable state machine
- `src/atlas/store.py` — SQLite FTS5 documents, semantic vectors, runs, events, manually saved notes
- `src/atlas/agent.py`, `team.py`, `router.py` — bounded model calls and explainable orchestration
- `src/atlas/providers.py`, `tools.py`, `costs.py` — gateway, tool boundaries and usage estimates
- `src/atlas/verification.py`, `calibration.py`, `evaluation.py` — surface evidence auditing and golden evaluations
- `src/atlas/api.py`, `schemas.py` — API, optional access guard, request validation
- `static/` — dependency-free dashboard
- `examples/claim_gold.json` — explicit calibration fixtures
- `tests/test_v04.py` — restart, cancellation, access, memory, and calibration integration checks

See [Architecture](docs/ARCHITECTURE.md), [Security](docs/SECURITY.md), [Deployment](docs/DEPLOYMENT.md), [Roadmap](docs/ROADMAP.md) and [Changelog](CHANGELOG.md).

### Publish when you're ready

The repository is prepared for your own GitHub account. See [GitHub publishing](docs/GITHUB_PUBLISHING.md) for local CLI commands and a pre-push secrets checklist. Connecting your account does **not** occur automatically, and this ZIP is not evidence that the code has been pushed to GitHub.
